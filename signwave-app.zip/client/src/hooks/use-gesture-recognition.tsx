import { useState, useCallback, useRef, useEffect } from "react";
import { GestureData } from "@/lib/gesture-data";
import { aiGestureService, AIGestureResult } from "@/lib/ai-gesture-service";

export interface GestureRecognitionHook {
  isScanning: boolean;
  currentGesture: GestureData | null;
  gestureStatus: string;
  gestureCount: number;
  startScanning: (videoElement: HTMLVideoElement) => void;
  stopScanning: () => void;
  lastDetection: Date | null;
}

const useGestureRecognition = (): GestureRecognitionHook => {
  const [isScanning, setIsScanning] = useState(false);
  const [currentGesture, setCurrentGesture] = useState<GestureData | null>(null);
  const [gestureStatus, setGestureStatus] = useState("Ready to detect");
  const [gestureCount, setGestureCount] = useState(0);
  const [lastDetection, setLastDetection] = useState<Date | null>(null);
  
  const scanIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const videoElementRef = useRef<HTMLVideoElement | null>(null);
  const isAnalyzingRef = useRef(false);

  // Initialize AI gesture service
  useEffect(() => {
    setGestureStatus("AI-powered recognition ready");
    aiGestureService.reset();
  }, []);

  const analyzeCurrentFrame = useCallback(async () => {
    if (!videoElementRef.current || !isScanning || isAnalyzingRef.current) {
      return;
    }

    try {
      isAnalyzingRef.current = true;
      setGestureStatus("AI analyzing gesture...");

      const result = await aiGestureService.analyzeGesture(videoElementRef.current);
      
      if (result) {
        // Convert AI result to GestureData format
        const gestureData: GestureData = {
          text: result.translation,
          hindi: result.hindi,
          confidence: result.confidence,
          gestureType: result.gestureType,
          category: 'general'
        };

        setCurrentGesture(gestureData);
        setGestureStatus(`AI detected: ${result.gestureType} (${Math.round(result.confidence * 100)}%)`);
        setGestureCount(prev => prev + 1);
        setLastDetection(new Date());
        
        if (window.showToast) {
          window.showToast({ 
            message: `AI detected: ${result.description}`, 
            type: 'success',
            duration: 2000
          });
        }
      } else {
        setGestureStatus("Looking for hand gestures...");
      }
    } catch (error) {
      console.error('Gesture analysis error:', error);
      setGestureStatus("Analysis error - retrying...");
    } finally {
      isAnalyzingRef.current = false;
    }
  }, [isScanning]);

  const startScanning = useCallback((videoElement: HTMLVideoElement) => {
    setIsScanning(true);
    setGestureStatus("Starting AI gesture recognition...");
    setCurrentGesture(null);
    setGestureCount(0);
    videoElementRef.current = videoElement;
    aiGestureService.reset();
    
    // Start continuous AI analysis
    const interval = setInterval(() => {
      analyzeCurrentFrame();
    }, 3000); // Analyze every 3 seconds
    
    scanIntervalRef.current = interval;
    
    if (window.showToast) {
      window.showToast({ 
        message: 'AI-powered continuous scanning started', 
        type: 'success' 
      });
    }
  }, [analyzeCurrentFrame]);

  const stopScanning = useCallback(() => {
    setIsScanning(false);
    setGestureStatus("AI scanning stopped");
    setCurrentGesture(null);
    videoElementRef.current = null;
    isAnalyzingRef.current = false;
    
    // Clear the interval
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }
    
    if (window.showToast) {
      window.showToast({ 
        message: 'AI scanning stopped', 
        type: 'info' 
      });
    }
  }, []);


  return {
    isScanning,
    currentGesture,
    gestureStatus,
    gestureCount,
    startScanning,
    stopScanning,
    lastDetection,
  };
};

export { useGestureRecognition };
