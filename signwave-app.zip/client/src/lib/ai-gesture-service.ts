import { gesturePatterns } from './gesture-data';

export interface AIGestureResult {
  gestureType: string;
  confidence: number;
  description: string;
  translation: string;
  hindi?: string;
}

export class AIGestureService {
  private lastAnalysisTime = 0;
  private readonly MIN_INTERVAL = 2000; // 2 seconds between analyses

  async analyzeGesture(videoElement: HTMLVideoElement): Promise<AIGestureResult | null> {
    const now = Date.now();
    if (now - this.lastAnalysisTime < this.MIN_INTERVAL) {
      return null;
    }

    try {
      // Capture frame from video
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      canvas.width = videoElement.videoWidth || 640;
      canvas.height = videoElement.videoHeight || 480;
      
      ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
      const imageData = canvas.toDataURL('image/jpeg', 0.8);

      this.lastAnalysisTime = now;

      // Send to server for AI analysis
      const response = await fetch('/api/analyze-gesture', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ imageData }),
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const result = await response.json();

      if (!result.gestureDetected || !result.isISLGesture || result.confidence < 0.7) {
        return null;
      }

      // Find matching gesture pattern
      const matchedGesture = gesturePatterns.find(g => g.gestureType === result.gestureType);
      
      if (!matchedGesture) {
        return null;
      }

      return {
        gestureType: result.gestureType,
        confidence: result.confidence,
        description: result.description,
        translation: matchedGesture.text,
        hindi: matchedGesture.hindi
      };

    } catch (error) {
      console.error('AI gesture analysis failed:', error);
      return null;
    }
  }

  reset() {
    this.lastAnalysisTime = 0;
  }
}

export const aiGestureService = new AIGestureService();