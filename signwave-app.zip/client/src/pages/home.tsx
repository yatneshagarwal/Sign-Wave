import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Contrast, Settings, Zap } from "lucide-react";
import CameraSection from "@/components/camera-section";
import TranslationPanel from "@/components/translation-panel";
import StatsPanel from "@/components/stats-panel";
import CustomCursor from "@/components/custom-cursor";
import { ToastContainer } from "@/components/toast-notification";
import { regions, GestureData } from "@/lib/gesture-data";

export default function Home() {
  const [selectedRegion, setSelectedRegion] = useState("MH");
  const [isListening, setIsListening] = useState(false);
  const [currentGesture, setCurrentGesture] = useState<GestureData | null>(null);
  const [gestureHistory, setGestureHistory] = useState<Array<{ gesture: GestureData; timestamp: Date }>>([]);

  const handleGestureComplete = (gesture: GestureData) => {
    setCurrentGesture(gesture);
    setGestureHistory(prev => [{ gesture, timestamp: new Date() }, ...prev]);
  };

  const handleHighContrast = () => {
    document.documentElement.classList.toggle('high-contrast');
    if (window.showToast) {
      window.showToast({ message: 'High contrast mode toggled', type: 'info' });
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <CustomCursor isListening={isListening} />
      <ToastContainer />
      
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-lg bg-background/80 border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-neon-teal to-neon-magenta rounded-lg flex items-center justify-center">
                <Zap className="w-4 h-4 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-neon-teal to-neon-magenta bg-clip-text text-transparent">
                  SignWave
                </h1>
                <p className="text-xs text-muted-foreground">Breaking silence</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                <SelectTrigger className="w-48" data-testid="region-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {regions.map((region) => (
                    <SelectItem key={region.code} value={region.code}>
                      {region.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={handleHighContrast}
                title="High Contrast Mode"
                data-testid="contrast-btn"
              >
                <Contrast className="w-4 h-4" />
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                title="Settings"
                data-testid="settings-btn"
              >
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          <CameraSection
            onGestureComplete={handleGestureComplete}
            isListening={isListening}
            onListeningChange={setIsListening}
          />
          
          <TranslationPanel
            currentGesture={currentGesture}
            selectedRegion={selectedRegion}
            gestureHistory={gestureHistory}
          />
        </div>
        
        <StatsPanel 
          isScanning={isListening}
          gestureHistory={gestureHistory}
        />
      </main>
    </div>
  );
}
